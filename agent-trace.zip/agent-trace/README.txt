Current-session snapshot captured while the app is active. This is not a post-exit final session export. Only this task session is included; credential patterns are redacted.
